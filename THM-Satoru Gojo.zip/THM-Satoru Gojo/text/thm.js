function InitThemeDashElements() {
    DashElements.CustomThemeBG = {};
    DashElements.CustomThemeBG.Image = new Image(`${PATHS.Theme}${UserConfig.Theme}/bg/game_bg.png`);
    DashElements.CustomThemeBG.Image.optimize();
    DashElements.CustomThemeBG.Image.filter = LINEAR;
    DashElements.CustomThemeBG.Fade = createFade();
}

InitThemeDashElements();
SetNewCustomBgImg(`${PATHS.Theme}${UserConfig.Theme}/bg/bg.png`);
UserConfig.BgColor = 12;
BgElements.BgColor.Next = UserConfig.BgColor;
BgElements.BgColor.Progress = 0.0;

